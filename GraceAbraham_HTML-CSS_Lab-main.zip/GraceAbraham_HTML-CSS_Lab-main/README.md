# Grace_Abraham
# HTML-CSS_Lab


I have done all 3 questions. The background video is of big size and failed at uploading to GitHUb.

